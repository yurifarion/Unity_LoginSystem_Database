<?php
//end
//Variables for the connection
	$servername = "localhost";
	$server_username =  "id8538434_yuriruf";
	$server_password = "yuri30697";
	$dbName = "id8538434_yurifarion";
	
//Variable from the user	
	$Nome = $_POST["usernamePost"]; 
	$Senha = $_POST["passwordPost"];
	$Creditos = $_POST["creditosPost"];
	
	
	//Make Connection
	$conn = new mysqli($servername, $server_username, $server_password, $dbName);
	//Check Connection
	if(!$conn){
		echo "Sem conexão :(";
		die("Connection Failed. ". mysqli_connect_error());
	}
	
			
		$sql = "INSERT INTO Usuario (Nome, Senha, Credito)
				VALUES ('".$Nome."','".$Senha."','".$Creditos."')";
				
		$result = mysqli_query($conn ,$sql);
		
	
	
	

?>

