<?php 
// Dados do banco de dados
	$servername = "localhost";
	$server_username =  "id8538434_yuriruf";
	$server_password = "yuri1234";
	$dbName = "id8538434_yurifarion";
	
	$Nome = $_POST["usernamePOST"]; // dados pegos no fomulario post
	$Senha = $_POST["passwordPOST"];// dados pegos no fomulario post
	// Connection
	$conn = new mysqli($servername,$server_username, $server_password, $dbName); // tentativa de conexão
	
	//checkdate
	if(!$conn){
		die("Connection failed". mysqli_connect_error()); // retorna o Feedback se não rolar conexão
		
	}
	$sql = "SELECT Senha FROM Usuario WHERE Nome = '".$Nome."'"; // comando SQL
	$result = mysqli_query($conn ,$sql); // resultados da pesquisa
	
	
	if(mysqli_num_rows($result) > 0){
		//show data for each row
	while($row = mysqli_fetch_assoc($result)){
			if($row['Senha'] == $Senha){
				echo "LoginSucces"; // senha bateu retorna sucesso
			}else echo "wrong password";// senha não bateu retorna fracasso
			
		}
	}else echo "User not Found";// não achou usuário retorna que o usuário esta perdido


?>