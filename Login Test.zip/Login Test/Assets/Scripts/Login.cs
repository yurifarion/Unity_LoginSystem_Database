﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class Login : MonoBehaviour {

	public Text result;

	public InputField name; // Caixa de texto do Unity
	public InputField password; // Caixa de texto do Unity

	public string inputUserName; // Dados do Usuáriom obtidos via textbox
	public string inputPassword; // Dados do Usuáriom obtidos via textbox

	string CreateUserURL = "https://thisisjustatext.000webhostapp.com/login.php"; // Endereço de Rede php ( isto deve estar online )

	public string[] items; // lista de itens
	// Use this for initialization

	IEnumerator CheckLogin(){
		inputUserName = name.text; //obtem texto da textbox
		inputPassword = password.text; //obtem texto da textbox
		WWWForm form = new WWWForm(); // Formulário Web
		form.AddField("usernamePOST", inputUserName); // adiciona itens no formulário para o POST do php
		form.AddField("passwordPOST", inputPassword); // adiciona itens no formulário para o POST do php

		WWW loginphp = new WWW(CreateUserURL,form); // cria formulá que irá receber os dados via GET da url acima
		yield return loginphp; // espera até receber algo
		string FeedBackTEXT = loginphp.text; // texto que recebe no feedback ( serve para ver se deu tudo certo )
		print (FeedBackTEXT);
		result.text = FeedBackTEXT; // mostra o texto feedback como resultado ( se deu boa ou não )


	}
	public void buttonLogin(){
		
		StartCoroutine(CheckLogin ());

	}
	public void buttonRegister(){

		Application.LoadLevel (1);

	}
	// Update is called once per frame
	void Update () {
		

	}
}
