﻿using UnityEngine;
using System.Collections;
/*


Este script funciona igual ao script de login, checar link de login para ver o processo



*/
using UnityEngine.UI;
public class Register : MonoBehaviour {
	public Text result;

	public InputField name;
	public InputField password;
	public InputField Creditos;

	public string inputUserName;
	public string inputPassword;
	public string inputcreditos;

	public int inputCreditos;

	string CreateUserURL = "https://thisisjustatext.000webhostapp.com/InsertUser.php";

	// Use this for initialization
	void Start () {

	}
	public void Registro(){
		StartCoroutine(CreateUser());


	}
	// Update is called once per frame


	IEnumerator CreateUser(){
		

		inputUserName = name.text;
		inputPassword = password.text;
		inputcreditos = Creditos.text;
		WWWForm form = new WWWForm();
		form.AddField("usernamePost", inputUserName);
		form.AddField("passwordPost", inputPassword);
		form.AddField("creditosPost", inputcreditos);

		WWW www = new WWW(CreateUserURL, form);
		yield return www;
		string FeedBackTEXT = www.text;
		if (FeedBackTEXT == "Sucesso")
			Application.LoadLevel (0);
		result.text = FeedBackTEXT;
		print(FeedBackTEXT);
	}

}